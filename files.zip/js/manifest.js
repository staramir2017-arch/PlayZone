/**
 * Utility to load and validate manifest. json
 */

const ManifestLoader = {
    async load(path = 'data/manifest.json') {
        try {
            const response = await fetch(path);
            if (!response.ok) {
                throw new Error(`HTTP Error:  ${response.status}`);
            }
            const manifest = await response.json();
            return this.validate(manifest);
        } catch (error) {
            console.error('Manifest loading error:', error);
            throw new Error('Failed to load game manifest');
        }
    },

    validate(manifest) {
        if (!manifest. games || !Array.isArray(manifest.games)) {
            throw new Error('Invalid manifest: missing games array');
        }

        return manifest.games.map(game => ({
            id:  game.id || `game_${Math.random()}`,
            title: game.title || 'Untitled Game',
            category: game.category || 'Uncategorized',
            description: game.description || '',
            tags: game.tags || [],
            thumbnail: game.thumbnail || '🎮',
            thumbnailUrl: game.thumbnailUrl || null,
            rating: Math.min(5, Math.max(0, game.rating || 0)),
            plays: game.plays || 0,
            path: game.path || `/games/${game.id}/index.html`
        }));
    }
};