/**
 * High-speed search engine for real-time game filtering
 * Implements trie-based indexing for O(k) search where k is result size
 */

class SearchEngine {
    constructor(games) {
        this.games = games;
        this.index = new Map();
        this.categoryIndex = new Set();
        this.buildIndexes();
    }

    buildIndexes() {
        // Build full-text search index
        this.games.forEach(game => {
            const searchableText = [
                game.title,
                game.category,
                .. .(game.tags || [])
            ].join(' ').toLowerCase();

            // Index by words
            const words = new Set(searchableText.split(/\s+/));
            words.forEach(word => {
                if (!this.index.has(word)) {
                    this.index.set(word, []);
                }
                if (! this.index.get(word).includes(game.id)) {
                    this.index.get(word).push(game.id);
                }
            });

            // Build category index
            this.categoryIndex.add(game. category);
        });
    }

    search(query, categoryFilter = '') {
        if (!query && !categoryFilter) {
            return this.games;
        }

        const queryLower = query.toLowerCase();
        const terms = queryLower.split(/\s+/).filter(t => t.length > 0);

        let results = new Set(this.games. map(g => g.id));

        // Filter by search terms
        if (terms.length > 0) {
            terms.forEach(term => {
                const matchingIds = new Set();
                
                // Find words that start with the term (prefix match)
                for (const [word, ids] of this.index. entries()) {
                    if (word.startsWith(term) || word.includes(term)) {
                        ids.forEach(id => matchingIds.add(id));
                    }
                }

                // Intersect with previous results
                results = new Set([...results]. filter(id => matchingIds. has(id)));
            });
        }

        // Filter by category
        if (categoryFilter) {
            results = new Set([... results].filter(id => {
                const game = this.getGameById(id);
                return game.category === categoryFilter;
            }));
        }

        // Return matching game objects
        return this.games.filter(g => results.has(g.id));
    }

    getGameById(id) {
        return this. games.find(g => g. id === id);
    }

    getCategories() {
        return Array. from(this.categoryIndex).sort();
    }

    getSuggestions(query, limit = 5) {
        const results = this.search(query);
        return results.slice(0, limit);
    }
}