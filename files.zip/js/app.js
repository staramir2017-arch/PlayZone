/**
 * PlayZone - Main Application Controller
 */

class PlayZoneApp {
    constructor() {
        this.games = [];
        this.searchEngine = null;
        this.virtualList = null;
        this. currentFilter = {
            search: '',
            category: ''
        };
        
        this.init();
    }

    async init() {
        try {
            // Load manifest
            await this.loadManifest();
            
            // Initialize search engine
            this.searchEngine = new SearchEngine(this.games);
            
            // Initialize virtual list
            this.virtualList = new VirtualList('virtualListContainer', 50);
            this.virtualList.setItems(this.games);
            
            // Setup event listeners
            this.setupEventListeners();
            
            // Update UI
            this.updateUI();
            
            console.log(`PlayZone initialized with ${this. games.length} games`);
        } catch (error) {
            console.error('Failed to initialize PlayZone:', error);
            this.showError('Failed to load game library');
        }
    }

    async loadManifest() {
        const response = await fetch('data/manifest.json');
        if (!response.ok) throw new Error('Failed to load manifest');
        
        const data = await response.json();
        this.games = data.games || [];
        
        // Update total count
        document.getElementById('totalCount').textContent = this.games.length;
    }

    setupEventListeners() {
        const searchInput = document.getElementById('searchInput');
        const categoryFilter = document.getElementById('categoryFilter');
        const clearFilters = document.getElementById('clearFilters');

        // Search with debouncing
        let searchTimeout;
        searchInput. addEventListener('input', (e) => {
            clearTimeout(searchTimeout);
            searchTimeout = setTimeout(() => this.performSearch(), 200);
        });

        // Category filter
        categoryFilter.addEventListener('change', (e) => {
            this.currentFilter.category = e.target.value;
            this.performSearch();
        });

        // Clear filters
        clearFilters. addEventListener('click', () => {
            this.currentFilter = { search: '', category: '' };
            searchInput.value = '';
            categoryFilter.value = '';
            this.performSearch();
        });

        // Populate category dropdown
        const categories = this.searchEngine.getCategories();
        categories.forEach(cat => {
            const option = document.createElement('option');
            option.value = cat;
            option.textContent = cat;
            categoryFilter.appendChild(option);
        });
    }

    performSearch() {
        const searchInput = document.getElementById('searchInput');
        this.currentFilter.search = searchInput.value;

        const results = this.searchEngine.search(
            this.currentFilter.search,
            this.currentFilter.category
        );

        this.displayResults(results);
    }

    displayResults(games) {
        const resultCount = document.getElementById('resultCount');
        
        if (games.length === 0) {
            this.virtualList.clear();
            const noResults = document.createElement('div');
            noResults.className = 'no-results';
            noResults.innerHTML = `
                <div class="no-results-icon">🔍</div>
                <p class="no-results-text">No games found</p>
                <p style="font-size: var(--font-size-sm); margin-top: var(--spacing-md);">
                    Try adjusting your search or filters
                </p>
            `;
            this.virtualList.container.appendChild(noResults);
            resultCount. textContent = 'No results';
        } else {
            this.virtualList.setItems(games);
            resultCount.textContent = `${games.length} game${games.length !== 1 ? 's' :  ''} found`;
        }
    }

    updateUI() {
        this.performSearch();
    }

    showError(message) {
        const container = document.getElementById('virtualListContainer');
        container.innerHTML = `
            <div class="no-results">
                <div class="no-results-icon">⚠️</div>
                <p class="no-results-text">${message}</p>
            </div>
        `;
    }
}

// Initialize when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    window.playZoneApp = new PlayZoneApp();
});