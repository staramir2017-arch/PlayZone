/**
 * Play Page Controller
 * Manages game loading and iframe communication
 */

class GamePlayer {
    constructor() {
        this.gameId = this.getGameIdFromUrl();
        this.gameData = null;
        this. init();
    }

    getGameIdFromUrl() {
        const params = new URLSearchParams(window. location.search);
        return params.get('id');
    }

    async init() {
        try {
            if (!this.gameId) {
                this.showError('No game specified');
                return;
            }

            // Load manifest and find game
            await this.loadGame();
            
            // Setup event listeners
            this.setupEventListeners();
            
            // Load game in iframe
            this.loadGameInFrame();
            
        } catch (error) {
            console.error('Player initialization error:', error);
            this.showError('Failed to load game');
        }
    }

    async loadGame() {
        const response = await fetch('data/manifest.json');
        if (!response.ok) throw new Error('Failed to load manifest');
        
        const manifest = await response.json();
        this.gameData = manifest.games.find(g => g.id === this.gameId);
        
        if (!this.gameData) {
            throw new Error(`Game ${this.gameId} not found`);
        }
        
        // Update page title and header
        document.getElementById('gameTitle').textContent = this.gameData.title;
        document.title = `${this.gameData.title} - PlayZone`;
    }

    loadGameInFrame() {
        const frame = document.getElementById('gameFrame');
        const overlay = document.getElementById('loadingOverlay');
        
        // Remove loading overlay when iframe loads
        frame.onload = () => {
            overlay.classList. add('hidden');
        };

        // Handle load errors
        frame.onerror = () => {
            this.showError('Failed to load game');
        };

        // Set iframe source
        frame.src = this. gameData.path;
    }

    setupEventListeners() {
        const backBtn = document.getElementById('backBtn');
        backBtn.addEventListener('click', () => this.goBack());
        
        // Also handle escape key
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                this.goBack();
            }
        });
    }

    goBack() {
        // Smooth transition back
        const container = document.querySelector('.play-container');
        container.style.opacity = '0.7';
        
        // Wait a moment for visual feedback, then navigate
        setTimeout(() => {
            window.location.href = 'index.html';
        }, 150);
    }

    showError(message) {
        const overlay = document.getElementById('loadingOverlay');
        overlay.innerHTML = `
            <div class="loading-spinner">
                <div style="font-size: 3rem; margin-bottom: var(--spacing-lg);">⚠️</div>
                <p>${message}</p>
                <button class="back-button" style="margin-top: var(--spacing-lg); background-color: var(--color-error);" onclick="window.location.href='index.html'">
                    Back to Library
                </button>
            </div>
        `;
    }
}

// Initialize when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    window.gamePlayer = new GamePlayer();
});