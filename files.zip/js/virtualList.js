/**
 * VirtualList - High-performance list rendering for 2500+ items
 * Uses Intersection Observer for automatic lazy loading
 */

class VirtualList {
    constructor(containerId, itemsPerPage = 50) {
        this.container = document.getElementById(containerId);
        this.itemsPerPage = itemsPerPage;
        this.currentItems = [];
        this.allItems = [];
        this.sentinel = null;
        this.isLoading = false;
        this.hasMore = true;
        this. currentIndex = 0;
        
        this.intersectionObserver = new IntersectionObserver(
            (entries) => this.handleIntersection(entries),
            { rootMargin: '200px' }
        );
        
        this.initSentinel();
    }

    initSentinel() {
        this.sentinel = document.createElement('div');
        this.sentinel.id = 'virtual-list-sentinel';
        this.container.appendChild(this.sentinel);
        this.intersectionObserver.observe(this. sentinel);
    }

    setItems(items) {
        this.allItems = items;
        this. currentIndex = 0;
        this. currentItems = [];
        this.hasMore = this.allItems.length > 0;
        this.container.innerHTML = '';
        this.initSentinel();
        this.loadMoreItems();
    }

    handleIntersection(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting && this.hasMore && ! this.isLoading) {
                this.loadMoreItems();
            }
        });
    }

    loadMoreItems() {
        if (this.isLoading || !this.hasMore) return;
        
        this.isLoading = true;
        const loadingIndicator = document.getElementById('loadingIndicator');
        if (loadingIndicator) loadingIndicator.style.display = 'flex';

        // Simulate async loading with requestAnimationFrame
        requestAnimationFrame(() => {
            const endIndex = Math.min(
                this.currentIndex + this. itemsPerPage,
                this.allItems.length
            );

            const newItems = this.allItems. slice(this.currentIndex, endIndex);
            newItems.forEach(item => {
                const element = this.createItemElement(item);
                this. container.insertBefore(element, this.sentinel);
                this.currentItems.push(item);
            });

            this.currentIndex = endIndex;
            this.hasMore = this.currentIndex < this.allItems.length;
            this.isLoading = false;

            if (loadingIndicator) loadingIndicator.style.display = 'none';
        });
    }

    createItemElement(item) {
        const div = document.createElement('div');
        div.className = 'game-card';
        div.href = `play. html?id=${item.id}`;
        div.innerHTML = `
            <div class="game-thumbnail">
                ${item.thumbnailUrl 
                    ? `<img src="${item.thumbnailUrl}" alt="${item.title}">` 
                    : `<div class="game-thumbnail-fallback">${item.thumbnail || '🎮'}</div>`
                }
            </div>
            <div class="game-content">
                <h3 class="game-title" title="${item.title}">${item.title}</h3>
                <span class="game-category">${item.category}</span>
                <div class="game-rating">
                    <span class="stars">${this.renderStars(item.rating)}</span>
                    <span>${item.rating. toFixed(1)}</span>
                </div>
            </div>
        `;
        div.style.cursor = 'pointer';
        div.onclick = (e) => {
            e. preventDefault();
            window.location.href = `play.html?id=${item.id}`;
        };
        return div;
    }

    renderStars(rating) {
        const fullStars = Math.floor(rating);
        const hasHalf = rating % 1 >= 0.5;
        let stars = '★'. repeat(fullStars);
        if (hasHalf) stars += '½';
        return stars;
    }

    clear() {
        this.container.innerHTML = '';
        this. currentItems = [];
        this. currentIndex = 0;
        this.initSentinel();
    }

    destroy() {
        this.intersectionObserver.disconnect();
        this.clear();
    }
}